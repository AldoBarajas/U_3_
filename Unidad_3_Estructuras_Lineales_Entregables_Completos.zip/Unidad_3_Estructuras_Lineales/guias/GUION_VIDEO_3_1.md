# Guion para el video de la Tarea 3.1 (5–7 minutos aproximados)

**Inicio:** Presentarse, mencionar la Unidad 3 y que se implementaron los algoritmos desde cero usando arreglos fijos sin `Stack<T>`, `Queue<T>` ni `List<T>` nativos.

1. Mostrar la solución de Visual Studio y el código de `StaticStack<T>`: `datos`, `top=-1`, `Push`, `Pop`, `Peek`, `IsEmpty` e `IsFull` (también alias `isEmpty` y `isFull`). Explicar LIFO y cómo cambian los índices.
2. Ejecución real: agregar tres enteros, retirar uno, consultar Peek. Probar capacidad llena y vacía; mencionar las excepciones.
3. Abrir `LinearQueue<T>`: explicar `front=0`, `rear=-1` y el motivo por el que una cola lineal no recicla celdas hasta vaciarse.
4. Abrir `CircularQueue<T>`: explicar `rear=(rear+1)%capacidad`, `front=(front+1)%capacidad`, `count`. Mostrar ejemplo `[1,2,3] -> Dequeue -> Enqueue(4) => [2,3,4]`.
5. Ejecutar `Pruebas` y leer el resumen **real**; si hay fallas, mostrarlas y corregirlas, no sustituir la salida.
6. Cerrar comparando costo O(1) de las operaciones fundamentales y O(C) de memoria por capacidad.

**Grabación:** capturar pantalla y webcam visible en la esquina inferior derecha. Subir el video **público al mismo canal** de las otras unidades.
