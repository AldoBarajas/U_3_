# Guía de publicación y evidencias — Unidad 3

## A. Compilar y probar en tu computadora

1. Instala/abre **Visual Studio 2022** y asegúrate de tener soporte para **.NET 8**.
2. Abre `codigo/EstructurasLineales.sln`; en el menú **Compilar**, elige **Compilar solución**.
3. En una terminal ubicada en la raíz, ejecuta `dotnet run --project codigo/Pruebas`. Si todo funciona, debe terminar con **39/39 correctas; 0 fallidas**. La cifra es una **expectativa de las pruebas**, no una validación de ejecución realizada en este entorno.
4. Abre cada proyecto de consola y ejecuta las demostraciones y casos de error/control.
5. Si un caso falla, corrige el código y repite la prueba **antes de subir evidencias**.

## B. Capturas de pantalla obligatorias o recomendadas

Crear capturas auténticas en `evidencias/`, usando `Win+Shift+S` o Recortes de Windows:

- `3_1_01_Pila_LIFO.png`: tres Push, Peek, Pop; mostrar top e índices.
- `3_1_02_Pila_LLena_Vacia.png`: error de Push sobre lleno y Pop sobre vacío.
- `3_1_03_Cola_Simple.png`: al extraer el primero no se recicla ranura si rear está al final.
- `3_1_04_Cola_Circular.png`: wrap-around con `2, 3, 4` y valores de `front` y `rear`.
- `3_1_05_Pruebas.png`: salida real de `Pruebas` y 39/39 si todas pasan.
- `3_2_01_Lista_Enlazada.png`: inserción en extremos y eliminación.
- `3_2_02_Dinamicas_Generic_T.png`: salida de pilas, colas y colecciones genéricas.
- `3_3_01_Demo_Restaurante.png`: orden Beto, Diego, Ana, Carla.
- `3_3_02_Registro_Interactivo.png`: alta de personas y fila de espera.
- `3_3_03_UML.png`: diagrama abierto en diagrams.net o Visual Studio.

Estas capturas **no están incluidas** porque requieren ejecutar el software en un entorno .NET real.

## C. Publicar en GitHub

Puedes crear **un solo repositorio público** para toda la Unidad 3, con sus subcarpetas. En la interfaz web de GitHub, crea un repositorio nuevo, por ejemplo `Unidad3-Estructuras-Lineales`. Después, desde una terminal en la carpeta raíz y con Git instalado:

```bash
git init
git add .
git commit -m "Unidad 3: pilas, colas, listas y restaurante"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/Unidad3-Estructuras-Lineales.git
git push -u origin main
```

**Reemplaza `TU_USUARIO` por tu usuario real** y asegúrate de crear antes el repositorio vacío correspondiente. Si ya existe un repositorio inicializado, no repitas `git init` ni cambies su remoto sin revisarlo.

En Teams, pega la URL del repositorio público, comprueba que se abre sin iniciar sesión y conserva como archivos visibles los `README`, `*.cs`, `*.csproj`, `*.drawio`, `*.pdf` y capturas.

## D. Videos de YouTube

Son **3 videos separados**, uno por cada tarea, subidos al **mismo canal del alumno**. Deben ser públicos, no privados ni ocultos. Usa OBS Studio u otro capturador de pantalla; añade la webcam como fuente de video, redúcela y colócala en la **esquina inferior derecha**. Sigue los guiones en esta carpeta. No leas solamente el documento: demuestra los resultados del programa.

| Tarea | Temas que mostrar | Entrega en Teams |
| --- | --- | --- |
| 3.1 | Push/Pop/Peek; overflow y underflow; diferencias de cola simple/circular; índices | Enlace público del video y GitHub |
| 3.2 | Lista propia, nodos, LIFO/FIFO; genéricos .NET; memoria estática y dinámica | Video público, PDF comparativo y fuente |
| 3.3 | Problema de restaurante; regla de prioridad; UML; simulación; pruebas de FIFO por prioridad | Video público, ejecutable/proyecto, reporte y repositorio |

### Lista final de verificación

- [ ] Compilación real en .NET 8 sin errores.
- [ ] 39 pruebas pasan localmente y se documentan fallos si existieran.
- [ ] Capturas originales incluidas en el repositorio.
- [ ] Tres PDF legibles adjuntados o accesibles desde el repositorio.
- [ ] Archivos `.drawio` editables y exportaciones de diagramas.
- [ ] Repositorio público accesible sin autenticación.
- [ ] Tres videos públicos del mismo canal, webcam abajo a la derecha.
- [ ] Tres enlaces de video y URL de GitHub pegados en Teams.
