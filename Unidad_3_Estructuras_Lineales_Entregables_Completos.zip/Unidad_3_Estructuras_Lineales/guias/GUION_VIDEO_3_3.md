# Guion para el video de la Tarea 3.3 (6–8 minutos aproximados)

**Introducción:** el restaurante necesita organizar su sala de espera. Los grupos con reserva preceden a los grupos sin reserva. Los empates se resuelven por orden de llegada.

1. Abrir `Tarea_3_3_Diagrama_UML.drawio` en diagrams.net; identificar `Program`, `RestaurantPriorityQueue`, `Node`, `ClienteTurno`, `TipoTurno`.
2. Mostrar el método `Enqueue`: un nodo nuevo se inserta después de todos los nodos de prioridad igual o superior; así se conserva FIFO dentro de cada nivel.
3. Mostrar `Dequeue` y `Peek`, explicando por qué son O(1) con un enlace al primer nodo, mientras que insertar puede ser O(n).
4. Ejecutar `dotnet run --project codigo/Tarea33_Restaurante -- --demo` (o desde Visual Studio). Leer el orden real de atención; debe ser Beto, Diego, Ana, Carla si la ejecución es correcta.
5. Usar el menú para registrar otra reserva y otro cliente sin reserva; listar turnos y atender al siguiente.
6. Ejecutar el proyecto `Pruebas`. Explicar al menos un caso de empate y uno con cola vacía.
7. Analizar desventaja: muchas reservas pueden postergar indefinidamente a clientes sin reserva; proponer tiempo máximo o cuotas de atención como mejora.

**Grabación:** webcam en la esquina inferior derecha y pantalla legible durante toda la defensa. Publicar video público en el mismo canal.
