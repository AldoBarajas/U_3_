# Guion para el video de la Tarea 3.2 (5–7 minutos aproximados)

**Inicio:** explicar que ahora se usan nodos que se crean al insertar, sin una capacidad fija previamente determinada.

1. Abrir `SinglyLinkedList<T>` y su `Node` privado; distinguir `head`, `tail`, `Value` y `Next`.
2. Mostrar el `.drawio` o SVG de lista enlazada y explicar insertar al inicio/final, eliminar primero y eliminar por valor.
3. Ejecutar `Tarea32_Dinamicas`: explicar el orden de los nodos y observar `LinkedStack<T>` LIFO y `LinkedQueue<T>` FIFO.
4. Mostrar los ejemplos genéricos nativos: `List<T>`, `Stack<T>`, `Queue<T>`. Aclarar que capacidad dinámica no significa necesariamente almacenamiento enlazado interno.
5. Abrir el PDF comparativo: espacio reservado en arreglos frente a referencias y sobrecarga de objetos por nodo; mencionar O(1), O(n) y acceso por índice.
6. Concluir cuándo conviene una cola circular estática y cuándo una lista enlazada.

**Grabación:** usar pantalla + cámara web visible en esquina inferior derecha. Publicar en el mismo canal que los otros dos videos.
