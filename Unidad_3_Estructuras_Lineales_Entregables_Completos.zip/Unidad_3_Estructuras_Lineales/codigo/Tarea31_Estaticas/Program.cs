using Unidad3.Estructuras;

internal static class Program
{
    private static readonly StaticStack<int> Pila = new(5);
    private static readonly LinearQueue<int> Simple = new(5);
    private static readonly CircularQueue<int> Circular = new(5);

    private static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        if (args.Contains("--demo")) { Demo(); return; }
        while (true)
        {
            Console.WriteLine("\nUNIDAD 3 | TAREA 3.1 - ESTRUCTURAS ESTÁTICAS");
            Console.WriteLine("1) Pila  2) Cola simple  3) Cola circular  4) Demostración  0) Salir");
            Console.Write("Selecciona: ");
            string? opcion = Console.ReadLine();
            if (opcion == "0") return;
            switch (opcion)
            {
                case "1": MenuPila(); break;
                case "2": MenuSimple(); break;
                case "3": MenuCircular(); break;
                case "4": Demo(); break;
                default: Console.WriteLine("Opción no válida."); break;
            }
        }
    }

    private static int PedirEntero()
    {
        while (true)
        {
            Console.Write("Valor entero: ");
            if (int.TryParse(Console.ReadLine(), out int numero)) return numero;
            Console.WriteLine("Introduce un entero válido.");
        }
    }

    private static void Ejecutar(Action accion)
    {
        try { accion(); }
        catch (InvalidOperationException ex) { Console.WriteLine("ERROR: " + ex.Message); }
        catch (OverflowException ex) { Console.WriteLine("ERROR: " + ex.Message); }
    }

    private static void MenuPila()
    {
        while (true)
        {
            Console.WriteLine($"\nPILA | top={Pila.TopIndex} | ocupación={Pila.Count}/{Pila.Capacity}");
            Console.WriteLine("1) Push  2) Pop  3) Peek  4) isEmpty/isFull  5) Ver  0) Volver");
            string? op = Console.ReadLine();
            if (op == "0") return;
            switch (op)
            {
                case "1": Ejecutar(() => Pila.Push(PedirEntero())); break;
                case "2": Ejecutar(() => Console.WriteLine("Sale: " + Pila.Pop())); break;
                case "3": Ejecutar(() => Console.WriteLine("Tope: " + Pila.Peek())); break;
                case "4": Console.WriteLine($"isEmpty={Pila.IsEmpty()} | isFull={Pila.IsFull()}"); break;
                case "5": Console.WriteLine("Base -> tope: " + string.Join(", ", Pila.Snapshot())); break;
                default: Console.WriteLine("Opción no válida."); break;
            }
        }
    }

    private static void MenuSimple()
    {
        while (true)
        {
            Console.WriteLine($"\nCOLA SIMPLE | front={Simple.FrontIndex}, rear={Simple.RearIndex}, n={Simple.Count}");
            Console.WriteLine("1) Enqueue  2) Dequeue  3) Peek  4) Estado  5) Ver  0) Volver");
            string? op = Console.ReadLine();
            if (op == "0") return;
            switch (op)
            {
                case "1": Ejecutar(() => Simple.Enqueue(PedirEntero())); break;
                case "2": Ejecutar(() => Console.WriteLine("Sale: " + Simple.Dequeue())); break;
                case "3": Ejecutar(() => Console.WriteLine("Frente: " + Simple.Peek())); break;
                case "4": Console.WriteLine($"isEmpty={Simple.IsEmpty()} | isFull={Simple.IsFull()}"); break;
                case "5": Console.WriteLine("Frente -> final: " + string.Join(", ", Simple.Snapshot())); break;
                default: Console.WriteLine("Opción no válida."); break;
            }
        }
    }

    private static void MenuCircular()
    {
        while (true)
        {
            Console.WriteLine($"\nCOLA CIRCULAR | front={Circular.FrontIndex}, rear={Circular.RearIndex}, n={Circular.Count}");
            Console.WriteLine("1) Enqueue  2) Dequeue  3) Peek  4) Estado  5) Ver  0) Volver");
            string? op = Console.ReadLine();
            if (op == "0") return;
            switch (op)
            {
                case "1": Ejecutar(() => Circular.Enqueue(PedirEntero())); break;
                case "2": Ejecutar(() => Console.WriteLine("Sale: " + Circular.Dequeue())); break;
                case "3": Ejecutar(() => Console.WriteLine("Frente: " + Circular.Peek())); break;
                case "4": Console.WriteLine($"isEmpty={Circular.IsEmpty()} | isFull={Circular.IsFull()}"); break;
                case "5": Console.WriteLine("Frente -> final: " + string.Join(", ", Circular.Snapshot())); break;
                default: Console.WriteLine("Opción no válida."); break;
            }
        }
    }

    private static void Demo()
    {
        // Se emplean instancias locales para no modificar las estructuras del menú.
        var p = new StaticStack<int>(3); p.Push(10); p.Push(20); p.Push(30);
        Console.WriteLine("PILA: [10,20,30]; Pop => " + p.Pop() + "; Peek => " + p.Peek());
        var s = new LinearQueue<int>(3); s.Enqueue(10); s.Enqueue(20); s.Enqueue(30);
        Console.WriteLine("SIMPLE: [10,20,30]; Dequeue => " + s.Dequeue());
        Console.WriteLine("SIMPLE: rear=" + s.RearIndex + ", isFull=" + s.IsFull() + " pese a haber sacado el frente.");
        var c = new CircularQueue<int>(3); c.Enqueue(10); c.Enqueue(20); c.Enqueue(30);
        c.Dequeue(); c.Enqueue(40);
        Console.WriteLine("CIRCULAR: " + string.Join(", ", c.Snapshot()) + $"; front={c.FrontIndex}; rear={c.RearIndex}");
    }
}
