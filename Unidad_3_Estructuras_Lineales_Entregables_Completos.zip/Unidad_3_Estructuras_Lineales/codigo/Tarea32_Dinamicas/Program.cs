using Unidad3.Estructuras;

internal static class Program
{
    private static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.WriteLine("UNIDAD 3 | TAREA 3.2 - ESTRUCTURAS DINÁMICAS");
        var lista = new SinglyLinkedList<string>();
        lista.AddLast("Ana"); lista.AddLast("Beto"); lista.AddFirst("Inicio");
        Console.WriteLine("LISTA propia: " + string.Join(" -> ", lista));
        Console.WriteLine("¿Contiene Beto? " + lista.Contains("Beto"));
        lista.Remove("Ana"); Console.WriteLine("Después de eliminar Ana: " + string.Join(" -> ", lista));

        var pila = new LinkedStack<int>(); pila.Push(3); pila.Push(7);
        Console.WriteLine($"PILA dinámica: Peek={pila.Peek()}; Pop={pila.Pop()}; restante={pila.Count}");
        var cola = new LinkedQueue<string>(); cola.Enqueue("A"); cola.Enqueue("B");
        Console.WriteLine($"COLA dinámica: Dequeue={cola.Dequeue()}; Peek={cola.Peek()}");

        // Demostración separada de las clases genéricas predefinidas solicitadas.
        var listaNativa = new List<int> { 1, 2, 3 };
        var pilaNativa = new Stack<int>(); pilaNativa.Push(10); pilaNativa.Push(20);
        var colaNativa = new Queue<int>(); colaNativa.Enqueue(100); colaNativa.Enqueue(200);
        Console.WriteLine("List<T>: " + string.Join(", ", listaNativa));
        Console.WriteLine("Stack<T>.Pop(): " + pilaNativa.Pop());
        Console.WriteLine("Queue<T>.Dequeue(): " + colaNativa.Dequeue());
        Console.WriteLine("Las colecciones .NET solo aparecen en la tarea dinámica, no en la estática.");
    }
}
