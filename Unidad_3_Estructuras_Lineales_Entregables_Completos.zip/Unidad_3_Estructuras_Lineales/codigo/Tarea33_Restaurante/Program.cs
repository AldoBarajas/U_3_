using Unidad3.Estructuras;

internal static class Program
{
    private static readonly RestaurantPriorityQueue Turnos = new();
    private static int proximoFolio = 1;

    private static void Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        if (args.Contains("--demo")) { Demo(); return; }
        while (true)
        {
            Console.WriteLine("\nRESTAURANTE | SISTEMA DE TURNOS CON PRIORIDAD");
            Console.WriteLine("1) Registrar cliente  2) Atender siguiente  3) Ver siguiente");
            Console.WriteLine("4) Mostrar fila  5) Ejecutar simulación  0) Salir");
            Console.Write("Opción: ");
            string? opcion = Console.ReadLine();
            try
            {
                switch (opcion)
                {
                    case "1": Registrar(); break;
                    case "2": Console.WriteLine("Atendido: " + Turnos.Dequeue()); break;
                    case "3": Console.WriteLine("Siguiente: " + Turnos.Peek()); break;
                    case "4": MostrarFila(); break;
                    case "5": Demo(); break;
                    case "0": return;
                    default: Console.WriteLine("Opción inválida."); break;
                }
            }
            catch (InvalidOperationException ex) { Console.WriteLine("Aviso: " + ex.Message); }
        }
    }

    private static void Registrar()
    {
        Console.Write("Nombre: ");
        string nombre = Console.ReadLine() ?? "";
        Console.Write("Número de personas: ");
        if (!int.TryParse(Console.ReadLine(), out int personas) || personas <= 0)
        { Console.WriteLine("El número de personas debe ser positivo."); return; }
        Console.Write("¿Tiene reserva? (s/n): ");
        string tipo = (Console.ReadLine() ?? "").Trim().ToLowerInvariant();
        if (tipo != "s" && tipo != "n") { Console.WriteLine("Responde s o n."); return; }
        if (string.IsNullOrWhiteSpace(nombre)) { Console.WriteLine("Nombre vacío."); return; }
        var turno = new ClienteTurno(proximoFolio, nombre, personas,
            tipo == "s" ? TipoTurno.Reserva : TipoTurno.SinReserva, DateTime.Now);
        Turnos.Enqueue(turno); proximoFolio++;
        Console.WriteLine("Registrado: " + turno);
    }

    private static void MostrarFila()
    {
        Console.WriteLine($"Turnos en espera: {Turnos.Count} | Reserva precede a SinReserva");
        foreach (ClienteTurno cliente in Turnos) Console.WriteLine(" - " + cliente);
    }

    private static void Demo()
    {
        // Simulación independiente; no altera los turnos registrados desde el menú.
        var q = new RestaurantPriorityQueue();
        DateTime inicio = new(2026, 11, 8, 18, 0, 0, DateTimeKind.Unspecified);
        q.Enqueue(new ClienteTurno(1, "Ana", 2, TipoTurno.SinReserva, inicio));
        q.Enqueue(new ClienteTurno(2, "Beto", 4, TipoTurno.Reserva, inicio.AddMinutes(1)));
        q.Enqueue(new ClienteTurno(3, "Carla", 3, TipoTurno.SinReserva, inicio.AddMinutes(2)));
        q.Enqueue(new ClienteTurno(4, "Diego", 2, TipoTurno.Reserva, inicio.AddMinutes(3)));
        Console.WriteLine("\nEJEMPLO: orden de llegada Ana, Beto, Carla, Diego");
        Console.WriteLine("ORDEN ESPERADO: Beto, Diego, Ana, Carla");
        while (!q.IsEmpty) Console.WriteLine("Atiende: " + q.Dequeue());
        Console.WriteLine("Fila vacía: " + q.IsEmpty);
    }
}
